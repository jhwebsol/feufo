<div class="custmernav-profile">
	<div class="custmernav">								
		<ul class="nav nav-justified">
			<li class="active-nav"><a href="seller-profile.php">Profile </a></li> 
			<li><a href="edit-seller-profile.php">Edit Profile </a></li> 
			<li><a href="seller-bank-details.php">Bank Details </a></li>
			<li><a href="seller-product-details.php">Product Details </a></li>
			<li><a href="seller-product-order-details.php">Seller Order Details </a></li>
			<li><a href="seller-remaining-products.php">Seller Product Order Balance </a></li>
			<li><a href="seller-balance-sheet-details.php">Seller Balance Sheet </a></li>
		</ul>
	</div>
</div>