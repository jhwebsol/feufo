<footer class="main-footer">
    <div class="pull-right hidden-xs"> </div> <strong>Copyrights &copy; <script type="text/javascript">
var d = new Date()
document.write(d.getFullYear())
        </script>Feufo. All Rights Reserved | Design & Developed By:<a href="https://www.jhweb.in/" target="_blank"> J H Web Solutions.</a></strong> </footer>
