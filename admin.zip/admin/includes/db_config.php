<?php session_start();
/*$servername = "localhost";
$username = "root";
$password = "";
$dbname = "feufo";
$conn = mysqli_connect($servername, $username, $password, $dbname);*/

$servername = "103.21.58.4:3306";
$username = "hirinscars";
$password = "Ee2ak5$6";
$dbname = "vethire_share";
$conn = mysqli_connect($servername, $username, $password, $dbname);
//$conn = new mysqli("103.21.58.4:3306", "hirinscars", "Ee2ak5$6", "vethire_share");

?>