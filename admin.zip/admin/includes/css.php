<?php include("includes/db_config.php");?>
<!DOCTYPE html>
<html lang="en-IN">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Feufo</title>

<link rel="stylesheet" href="assest/css/bootstrap.min.css">
<link rel="stylesheet" href="assest/css/font-awesome.min.css">
<link rel="stylesheet" href="assest/css/jquery-jvectormap.css">
<link rel="stylesheet" href="assest/css/AdminLTE.min.css">
<link rel="stylesheet" href="assest/css/_all-skins.min.css">
<link rel="stylesheet" href="assest/css/all.css">
<link rel="stylesheet" href="assest/css/square/blue.css">
<link rel="stylesheet" href="assest/css/ionicons.min.css"> 
<link rel="stylesheet" href="assest/iCheck/flat/blue.css">
<link rel="stylesheet" href="assest/css/jhcustom-bootstrap-margin-padding.css">
<link rel="stylesheet" href="assest/css/custom.css">
<link rel="stylesheet" href="assest/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="assest/css/daterangepicker.css">
<link rel="stylesheet" href="assest/css/bootstrap-datepicker.min.css">
<link rel="stylesheet" href="assest/css/buttons.dataTables.min.css">
<!--<link rel="stylesheet" href="assest/css/select2.min.css">-->
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link href="summernote/summernote.css" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css2?family=Nunito&display=swap" rel="stylesheet"> 
</head> 
