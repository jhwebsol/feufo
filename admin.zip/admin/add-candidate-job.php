<?php include("includes/css.php"); ?>
<style>
.cdy div{ 
width:31%;
float:left;
margin:10px;
}  
hr{
    border:1px #e96125 solid!important;
}
</style>
<?php
if (isset($_POST['submit'])) {
extract($_POST);
 date_default_timezone_set('Asia/Kolkata');
 $datetime = date('Y-m-d H:i:s');
$ip=$_SERVER['REMOTE_ADDR']; 
$sql_cat="SELECT * from category where id='$category_id'";
$exe_cat=mysqli_query($conn,$sql_cat);
$res_cat=mysqli_fetch_array($exe_cat);
$sql_scat="SELECT * from sub_category where id='$sub_category_id'";
$exe_scat=mysqli_query($conn,$sql_scat);
$res_scat=mysqli_fetch_array($exe_scat);
$category = strtolower(str_replace(" ", "-", $res_cat['cat_name']));
$sub_category = strtolower(str_replace(" ", "-", $res_scat['sub_category_name']));
$emp_name = strtolower(str_replace(" ", "-", $emp_name));
$emps_name = mysqli_real_escape_string($conn,$emp_name);
$tmp_file = $_FILES['img']['tmp_name'];
$ext = pathinfo($_FILES["img"]["name"], PATHINFO_EXTENSION);
$rand = md5(uniqid().rand());
$image = $rand.".".$ext;
move_uploaded_file($tmp_file,"emp/".$image);

$tmp_file = $_FILES['img2']['tmp_name'];
$ext = pathinfo($_FILES["img2"]["name"], PATHINFO_EXTENSION);
$rand = md5(uniqid().rand());
$image2 = $rand.".".$ext;
move_uploaded_file($tmp_file,"emp/".$image2);

$tmp_file = $_FILES['img3']['tmp_name'];
$ext = pathinfo($_FILES["img3"]["name"], PATHINFO_EXTENSION);
$rand = md5(uniqid().rand());
$image3 = $rand.".".$ext;
move_uploaded_file($tmp_file,"emp/".$image3);

$tmp_file = $_FILES['img4']['tmp_name'];
$ext = pathinfo($_FILES["img4"]["name"], PATHINFO_EXTENSION);
$rand = md5(uniqid().rand());
$image4 = $rand.".".$ext;
move_uploaded_file($tmp_file,"emp/".$image4);
$tmp_file = $_FILES['img5']['tmp_name'];
$ext = pathinfo($_FILES["img5"]["name"], PATHINFO_EXTENSION);
$rand = md5(uniqid().rand());
$image5 = $rand.".".$ext;
move_uploaded_file($tmp_file,"emp/".$image5);
$tmp_file = $_FILES['resume']['tmp_name'];
$ext = pathinfo($_FILES["resume"]["name"], PATHINFO_EXTENSION);
$rand = md5(uniqid().rand());
$resume = $rand.".".$ext;
move_uploaded_file($tmp_file,"emp/".$resume);
$vdfile_name = $_FILES['video_file']['name'];
    $vdext = pathinfo($_FILES["video_file"]["name"], PATHINFO_EXTENSION);
    $rands = md5(uniqid().rand());
     $video_files = $rands.".".$vdext;
     $vdfile_size = $_FILES['video_file']['size'];
    $allowed_extensions = array("webm", "mp4", "ogv");
    $file_size_max = 2147483648;
    $pattern = implode ($allowed_extensions, "|");
    $vdfile_type = end(explode(".", $vdfile_name));
    if (!empty($vdfile_name))
    {    //here is what I changed - as you can see above, I used implode for the array
        // and I am using it in the preg_match. You pro can do the same with file_type,
        // but I will leave that up to you
        if (preg_match("/({$pattern})$/i", $vdfile_name) )
        {
            if (($vdfile_type == "webm") || ($vdfile_type == "mp4") || ($vdfile_type == "ogv"))
            {
                if ($_FILES['video_file']['error'] > 0)
                {
                    echo "Unexpected error occured, please try again later.";
                } else {
                    if (file_exists("emp/".$vdfile_name))
                    {
                        echo $vdfile_name." already exists.";
                    } else {
                        move_uploaded_file($_FILES["video_file"]["tmp_name"], "emp/".$video_files);
                        echo "Stored in: " . "emp/".$video_files;
                    }
                }
            } else { echo "<script>alert('Invalid video format!!!'); 
                            </script>";
            }
        }else{ echo "<script>alert('Video size is more please upload another video!!!'); 
                            </script>";
        }
    } 
    if(file_exists('../'.$category.'/'.$sub_category)){
        if(!file_exists('../'.$category.'/'.$sub_category.'/'.$emps_name)){
            if(copy('../candidate-job-detail.php', '../'.$category.'/'.$sub_category.'/'.$emps_name.'.php')) {
            $skill = implode(',',$dg_id);    
            $options = [
                'cost' => 11,
            ];
            $passwordFromPost = $_POST['password'];
            $passwordhash = password_hash($passwordFromPost, PASSWORD_BCRYPT, $options);
            $sql="INSERT into employee_details(cat_id,subcat_id,dg_id,emp_name,email_id,password,exp_salary,salary,location,job_type,avalibility,experience_level,assetment_link,video_interview,resume,github,linkedin,image,image2,image3,image4,image5,title,meta_keyword,created_date) values ('$category_id','$sub_category_id','$skill','$emp_name','$email_id','$passwordhash','$exp_salary','$salary','$location','$job_type','$avalibility','$experience_level','$assetment_link','$video_files','$resume','$github','$linkedin','$image','$image2','$image3','$image4','$image5','$title','$meta_keyword','$datetime')";
            if  (mysqli_query($conn, $sql)) {
                $last_id= mysqli_insert_id($conn);
               
                 echo "<script> 
                                alert('Your Candidate have added successfully!!!'); 
                                location.replace('candidate-job.php');
                            </script>";
            }
            else { 
                    echo "  <script> 
                                alert('There are some problem please try again!!!'); 
                                location.replace('candidate-job.php');
                            </script>";
                }
            } 
            else {
                echo "  <script> 
                            alert('There are some problem please try again!!!'); 
                            location.replace('candidate-job.php');
                        </script>";
            }
        }
        else{ 
            echo "  <script> 
                        alert('Candidate Name aleady exists, please change the and try again!!!'); 
                        location.replace('candidate-job.php');
                    </script>";
        }
    }
    else{ 
        echo "  <script> 
                    alert('Candidate not exists, please check and try again!!!'); 
                    location.replace('candidate-job.php');
                </script>";
    }
}


if(isset($_POST['update']))
{
extract($_POST);
$id=$_POST["cat_id"];
$sql1 ="UPDATE  sub_category  SET category_id='$cat_name',sub_category_name='$subcat_name' WHERE id='$id'"; 
$res=mysqli_query($conn,$sql1) or die(mysqli_error());
}
?>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <?php include("includes/header.php")?>
        <?php include("includes/sidebar.php")?>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <!-- Main content -->
            <section class="content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="box box-danger">
                            <div class="box-header">
                                <h3 class="box-title">Add Property Details</h3>
                            </div>
                            <div class="box-body">
                                <form method="post" action="" enctype="multipart/form-data">
                                    <div class="form-group">
                                        
                                        <div class="col-md-4">
                                            <label>Category:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                    <select name="category_id" id="cat_id" class="form-control">
                                                <option>Select</option>
                                                 <?php
                                                    $sql2="SELECT * from category";
                                                    $exe2=mysqli_query($conn,$sql2);
                                                    while ($res2=mysqli_fetch_array($exe2))
                                                    {
                                                    ?>
                                                    <option value="<?php echo $res2['id']; ?>"><?php echo $res2['cat_name'];?></option>
                                                    <?php
                                                    }
                                                    ?>
                                            </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <label>Sub-Category:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <select name="sub_category_id" id="sub_cat" class="form-control">
                                                <option>Select</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <label>Skills:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <select type="text" name="dg_id[]" class="form-control" multiple>
                                                <option>Select</option>
                                                 <?php $sqlqr=mysqli_query($conn,"SELECT * from designation");
                                                    while ($resqr=mysqli_fetch_array($sqlqr)){ ?>
                                                <option value="<?= $resqr['id']; ?>"><?= $resqr['dname']; ?></option><?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Candidate Name:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="text" name="emp_name" class="form-control" placeholder="Enter Candidate Name">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Candidate Location:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="text" name="location" class="form-control" placeholder="Enter Candidate Location">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Email ID/Username:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="text" name="email_id" class="form-control" placeholder="Enter Candidate Email Id" required>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Password:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="password" name="password" class="form-control" placeholder="Enter password">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Candidate job type:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <select class="chosen-select" name="job_type">
                                                    <option>Select Job Type</option>
                                                     <option>Freelance</option>
                                                    <option>Full Time</option>
                                                    <option>Part Time</option> 
                                                 </select>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Avalibility:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="text" name="avalibility" class="form-control" placeholder="Enter avalibility">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Experience Level:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="text" name="experience_level" class="form-control" placeholder="Enter Title ">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Expected Salary:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="text" name="exp_salary" class="form-control" placeholder="Enter Title ">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Negotiable Salary:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="text" name="salary" class="form-control" placeholder="Enter Title ">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Assetment link:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="text" name="assetment_link" class="form-control" placeholder="Enter Assetment link">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Github link:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="text" name="github" class="form-control" placeholder="Enter Github link">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Linkedin link:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="text" name="linkedin" class="form-control" placeholder="Enter Github link">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Title:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="text" name="title" class="form-control" placeholder="Enter Title ">
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-12">
                                            <label> Meta Keyword:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <textarea class="form-control" rows="5" name="meta_keyword" placeholder="Meta Keyword "></textarea>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Image 1:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="file" name="img" class="form-control" >
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Image 2:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="file" name="img2" class="form-control" >
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Image 3:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="file" name="img3" class="form-control" >
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Image 4:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="file" name="img4" class="form-control" >
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Image 5:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="file" name="img5" class="form-control" >
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Resume:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="file" name="resume" class="form-control" >
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label>Video Interview:</label>
                                            <div class="input-group">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-suitcase"></i>
                                                </div>
                                                <input type="file" name="video_file" class="form-control" >
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="col-md-4 mt-20">
                                        <div class="form-group">
                                            <input type="submit" name="submit" class="btn btn-success btn-md" value="Submit">
                                        </div>
                                    </div>
                                </form>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <?php include("includes/footer.php")?>
    </div>
    <?php include("includes/js.php")?>
    <script>
        $('.add').click(function() {
            $('.block:last').before('<div class="block" style="margin-bottom:10px;font-size:16px;" ><b><u>Add Another Product Details(No. Of Quantity, No. Of Items, Price,..) ....</u></b><span class="remove btn btn-sm btn-danger"><i class="fa fa-trash"></i></span></div>');
        });
        $('.optionBox').on('click', '.remove', function() {
            $(this).parent().remove();
        });


        $(document).ready(function(){
            $('#cat_id').on('change', function(){
                var cat_id = $(this).val();
               // alert(cat_id);
                if(cat_id){
                    $.ajax({  
                        type:'POST',
                        url:'ajax_get_subsub_cat.php',
                        data:'cat_id='+cat_id,
                        success:function(html){
                            $('#sub_cat').html(html);
                           // console.log(html);
                           // $('#city').html('<option value="">Select Division</option>'); 
                        }
                    }); 
                }
            });

                $('#sub_cat').on('change', function(){
                var scat_id = $(this).val();
                if(scat_id){
                    $.ajax({
                        type:'POST',
                        url:'ajax_get_subsub_cat.php',
                        data:'scat_id='+scat_id,
                        success:function(html){
                            $('#subsub_cat').html(html);
                        }
                    }); 
                }
            });
        });
    </script>
    <script> 
      $('#summernote_editor').summernote({
         tabsize: 2,
        height: 400,
            spellCheck: true,
    toolbar: [
      ['style', ['style']],
      ['font', ['bold', 'underline', 'italic', 'superscript', 'subscript', 'clear']],
      ['fontname', ['fontname','fontsize']],
      ['color', ['color']],
      ['para', ['ul', 'ol', 'paragraph']],
      ['table', ['table']],
      ['insert', ['link', 'picture', 'video']],
      ['view', ['fullscreen', 'help', 'undo', 'redo']],
    ],
    callbacks: {
        onImageUpload: function(files, editor, welEditable) {
            sendFile(files[0], editor, welEditable);
        }
    }
      });
   function sendFile(file, editor, welEditable) {
    data = new FormData();
    data.append("file", file);
    $.ajax({
        data: data,
        type: "POST",
        url: "upload_img.php",
        cache: false,
        processData: false,
        contentType: false,
        success: function(url) {
            var image = $('<img>').attr('src', url);
            $('#summernote_editor').summernote("insertNode", image[0]);
        }
    });
}
    </script> 
</body>
</html>