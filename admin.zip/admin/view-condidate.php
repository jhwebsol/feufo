<?php include("includes/css.php");
$id=$_GET["id"];
$sql="select sub_category.sub_category_name,category.cat_name,employee_details.* from employee_details join category on employee_details.cat_id=category.id join sub_category on employee_details.subcat_id=sub_category.id where employee_details.id=".$id;
$result = mysqli_query($conn, $sql);
?>
<body class="hold-transition skin-blue sidebar-mini">
	<div class="wrapper">
		<?php include("includes/header.php");?>
		<?php include("includes/sidebar.php");?>
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<section class="content-header">
				<h1>
					Dashboard
					<small>Control panel</small>
				</h1>
				<ol class="breadcrumb">
					<li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
					<li class="active">Dashboard</li>
				</ol>
			</section>
			<!-- Main content -->
			<section class="content">
				<div class="row">
					<div class="col-xs-12">
						<div class="box box-danger">
							<div class="box-header">
								<div class="row">
									<div class="col-md-4">
										<h3 class="box-title">View Candidate Job Details</h3>
									</div>
									<div class="col-md-1 pull-right"><a href="candidate-job.php"><button class="btn btn-flat btn-custom2 btn-block"><i class="fa fa-arrow-left"></i> Back</button></a> </div>
								</div>
							</div>
							<div class="box-body">
								<div class="nav-tabs-custom">
									<div class="table-responsive">
										<table class="table table-bordered table-stripped table-hover">
											<thead></thead>
											<tbody>
									        <?php while($res= mysqli_fetch_array($result)){ 
									          ?>
									          <tr>
													<th>Category</th>
													 <td><?php echo $res['cat_name']; ?></td>
													<th>Sub Category:</th>
													  <td><?php echo $res['sub_category_name']; ?></td> 
												</tr>
												<tr class="odd"> 
												    <th>Candidate Name: </th>
													<td> <?php echo $res['emp_name']; ?></td> 
												    <th>Skills: </th><td>
												    <?php $did=explode(",",$res['dg_id']);
												    foreach($did as $pm_id){
												    $sqlqr=mysqli_query($conn,"SELECT * from designation where id='".$pm_id."'");
                                                    while ($resqr=mysqli_fetch_array($sqlqr)){ ?>
													 <?php echo $resqr['dname'].","; } } ?></td> 
												</tr>
												<tr class="even"> 
												  <th>Expected salary:</th>
												  <td><?php echo $res['exp_salary']; ?> </td>
												<th>Negotiable salary:</th>
												  <td colspan="3"><?php echo $res['salary']; ?> </td>
												</tr> 

												<tr class="odd"> 
												  <th>Location:</th>
												  <td><?php echo $res['location']; ?></td> 
												  <th>Job type:</th>
												  <td><?php echo $res['job_type']; ?> </td>
												</tr> 
												<tr class="even">		
												    <th>Avalibility: </th>
													<td><?php echo $res['avalibility']; ?></td> 
													<th>Experience level : </th>
													<td><?php echo $res['experience_level']; ?></td> 	
												</tr>
												<tr class="even">		
												    <th>Assetment link: </th>
													<td><?php echo $res['assetment_link']; ?></td> 
													<th>Github: </th>
													<td><?php echo $res['github']; ?></td> 	
												</tr>
												<tr class="odd">	
													<th>Email Id: </th>
													<td><?php echo $res['email_id']; ?></td> 	
													<th>Linkedin: </th>
													<td><?php echo $res['linkedin']; ?> </td> 
												</tr>
												<tr class="even">	
													<th>Image: </th>
													<td><img src="emp/<?php echo $res['image']; ?>" style="width:30px;"></td> 	
													<th>Image 2: </th>
													<td><img src="emp/<?php echo $res['image2']; ?>" style="width:30px;"></td> 
												</tr>
												<tr class="odd">
													<th>Image 3: </th>
													<td><img src="emp/<?php echo $res['image3']; ?>" style="width:30px;"></td> 
											  	<th>Image 4:</th>
												<td><img src="emp/<?php echo $res['image4']; ?>" style="width:30px;"></td> 											
												</tr>
												<tr class="even">
													<th>Image 5:</th>
													<td><img src="emp/<?php echo $res['image5']; ?>" style="width:30px;"></td> 
												    <th>Total Rooms:</th>
													<td><video  controls height="80px" width="150px"><source src="emp/<?php echo $res['video_interview']; ?>" type="video/mp4">Your browser does not support the video tag.</video></td> 
												</tr>
												<tr class="odd">
													<th>Resume:</th>
													<td><?php echo $res['resume']; ?></td> 
												</tr>
												<tr class="even">	
													<th>Seo Title: </th>
													<td colspan="3"><?php echo $res['title']; ?></td>
												 </tr>
												<tr class="odd">	
													<th>Seo Description: </th>
													<td colspan="3"><?php echo $res['meta_keyword']; ?></td>
												 </tr> 
											    <?php } ?>
											</tbody>
											<tfoot> </tfoot>
										</table> 
									</div>
								</div>
							</div>  
						</div> 
					</div> 
				</div> 
			</section> 
		</div> 
		<?php include("includes/footer.php");?>
		<div class="control-sidebar-bg"></div>
	</div>
	<?php include("includes/js.php");?>
</body>
</html>
