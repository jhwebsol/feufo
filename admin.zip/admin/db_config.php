<?php session_start();
/*$servername = "localhost";
$username = "root";
$password = "";
$dbname = "feufo";
$conn = mysqli_connect($servername, $username, $password, $dbname);

$servername = "localhost";
$username = "vethire_hydsopro";
$password = "^PvKQL?#ljZX";
$dbname = "vethire_prop";
$conn = mysqli_connect($servername, $username, $password, $dbname);*/
$conn = new mysqli("103.21.58.4:3306", "hirinscars", "Ee2ak5$6", "vethire_share");

?>